// 0 = Piedra
// 1 = Papel
// 2 = Tijera

alert("¡¡¡Vamos a jugar un juego de piedra, papel, o tijeras!!!");
alert("Elige alguna de las tres opciones, la computadora también elegirá. ¡Suerte!")

let eleccionCompu;


function hacerJugada(eleccion) {
    eleccionCompu = getRandomint(0, 2);
}


function getRandomint(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}


function hacerJugada(eleccion) {
    eleccionCompu = getRandomint(0, 2);
    switch (eleccion) {
        case 0:
            switch (eleccionCompu) {
                case 0:
                    alert("Empate");
                    alert("Tu puntuación no cambió");
                break;
                case 1:
                    alert("¡Perdiste!");
                break;
                case 2:
                    alert("¡Ganaste!");
                break;
            }
        break;
        case 1:
            switch (eleccionCompu) {
                case 1:
                   alert("Empate");
                   alert("Tu puntuación no cambió");
                break;
                case 2:
                    alert("¡Perdiste!");
                break;
                case 0:
                    alert("¡Ganaste!");
                break;
            }
        break;
        case 2:
            switch (eleccionCompu) {
                case 2:
                    alert("Empate");
                    alert("Tu puntuación no cambió");
                break;
                case 0:
                    alert("¡Perdiste!");
                break;
                case 1:
                    alert("¡Ganaste!");
                break;
            }
            break;

        default:
        break;

    }
}

let numr = 0;

let punt;

//punt = numr - 1 si perdiste
//punt = numr + 1 si ganaste
//punt = numr si empataste